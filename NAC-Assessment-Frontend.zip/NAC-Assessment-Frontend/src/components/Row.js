import React from 'react'
import { useExcelContext } from './Context/ExcelContext'

const Row = ({data}) => {
    console.log(data)
  let dummyData = Object.values(data)
  console.log(dummyData)
    return (
   <tr>
        {dummyData.map(item=><td key={item}>{item}</td>)}
   </tr>
  )
}

export default Row



/*
git remote add origin https://github.com/shreyashbijlwanOP/ajinkiya.git
git branch -M main
git push -u origin main
*/